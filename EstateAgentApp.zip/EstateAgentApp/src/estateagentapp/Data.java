/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estateagentapp;

/**
 *
 * @author zakiyya khan
 */
public class Data {
    
    private String location;
    private String name;
    private String price;
    private String commission;

    public Data(String location, String name, String price, String commission) {
        this.location = location;
        this.name = name;
        this.price = price;
        this.commission = commission;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getCommission() {
        return commission;
    }

    public void setCommission(String commission) {
        this.commission = commission;
    }
}