/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estateagentapp;

/**
 *
 * @author zakiyya khan
 */
public interface IEstateAgent {
    
   double CalculateCommission(String propertyPrice, String agentCommission);

    boolean ValidateData(Data dataToValidate);
}
