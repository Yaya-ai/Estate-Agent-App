/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estateagentapp;

/**
 *
 * @author zakiyya khan
 */

// Define the class EstateAgent that implements the IEstateAgent interface
public class EstateAgent implements IEstateAgent {
    @Override
    public double CalculateCommission(String propertyPrice, String agentCommission) {
        try {
            // Convert the property price and agent commission from strings to doubles
            double price = Double.parseDouble(propertyPrice);
            double commission = Double.parseDouble(agentCommission);

            // Check if the commission percentage is valid (between 0 and 100)
            if (commission < 0 || commission > 100) {
                // Return the property price itself as an indication of an unsuccessful calculation
                return price;
            }

            // Calculate the commission by multiplying the price by the commission divided by 100
            return price * (commission / 100);
        } catch (NumberFormatException e) {
            // Return the property price itself as an indication of an unsuccessful calculation
            return Double.parseDouble(propertyPrice);
        }
    }

    @Override
    public boolean ValidateData(Data dataToValidate) {
        // Extract data from the Data object
        String location = dataToValidate.getLocation();
        String name = dataToValidate.getName();
        String price = dataToValidate.getPrice();
        String commission = dataToValidate.getCommission();

        // Check if any of the required fields are empty or if price/commission are not numeric
        if (location.isEmpty() || name.isEmpty() || !isNumeric(price) || !isNumeric(commission)) {
               // Return false if any of the conditions are not met
            return false;
        }

        // Convert price and commission to double values
        double priceValue = Double.parseDouble(price);
        double commissionValue = Double.parseDouble(commission);

         // Check if price and commission are greater than zero
        return priceValue > 0 && commissionValue > 0;
    }

    // Helper method to check if a string is numeric
    private boolean isNumeric(String s) {
        try {
            // Attempt to parse the string as a double
            Double.parseDouble(s);
             // Return true if successful
            return true;
        } catch (NumberFormatException e) {
             // Return false if parsing fails (not a valid number)
            return false;
        }
    }
}
