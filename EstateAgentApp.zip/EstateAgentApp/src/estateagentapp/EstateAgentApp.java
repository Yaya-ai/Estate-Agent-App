/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estateagentapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author zakiyya khan
 */

public class EstateAgentApp {
    /**
     *** Java combobox, Available at: https://www.youtube.com/watch?v=EAxV_eoYrIg
     *** JTextField | Java Swing Tutorial for Beginners: Available at:
     https://www.youtube.com/watch?v=dcdlqhMluC0
     *** JLabel Example Java | Java Programming Tutorial 2020., Available at: 
     https://www.youtube.com/watch?v=hyWNd1Y912s
     * Java GUI Tutorial #25 - Create A MenuBar, Menu, Sub Menu With Java GUI ActionListener, MenuListener
     *Available at: https://www.youtube.com/watch?v=oiL9AlDWbQc
     */
    
    // Declare and initialize GUI components
  String[] locations = {"Cape Town", "Durban", "Pretoria"};
    JComboBox<String> locationComboBox = new JComboBox<>(locations);
    JTextField nameTextField = new JTextField();
    JTextField priceTextField = new JTextField();
    JTextField commissionTextField = new JTextField();
    JTextArea reportTextArea = new JTextArea();
    JLabel locationLabel = new JLabel("AGENT LOCATION:");
    JLabel nameLabel = new JLabel("ESTATE AGENT NAME:");
    JLabel priceLabel = new JLabel("PROPERTY PRICE:");
    JLabel commissionLabel = new JLabel("COMMISSION PERCENTAGE:");
    JLabel reportLabel = new JLabel("ESTATE AGENT REPORT:");
    JPanel panel = new JPanel(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    JFrame frame = new JFrame("Estate Agent Report");
    JMenuBar menuBar = new JMenuBar();
    JMenu fileMenu = new JMenu("File");
    JMenuItem exitMenuItem = new JMenuItem("Exit");
    JMenu toolsMenu = new JMenu("Tools");
    JMenuItem processMenuItem = new JMenuItem("Process Report");
    JMenuItem clearMenuItem = new JMenuItem("Clear");
    JMenuItem saveMenuItem = new JMenuItem("Save Report");

    public EstateAgentApp() {
        /**
         * Java Tutorial 47 (GUI) - GridBagLayout and GridBagConstraints
         *Available at: https://www.youtube.com/watch?v=g2vDARb7gx8
         */
        
        // Set the default close operation to exit the application
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set the layout constraints
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.gridy = 0;

        // Add components to the panel
        panel.add(locationLabel, gbc);
        gbc.gridx = 1;
        panel.add(locationComboBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(nameLabel, gbc);
        gbc.gridx = 1;
        panel.add(nameTextField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(priceLabel, gbc);
        gbc.gridx = 1;
        panel.add(priceTextField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(commissionLabel, gbc);
        gbc.gridx = 1;
        panel.add(commissionTextField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(reportLabel, gbc);
        gbc.gridx = 1;
        panel.add(reportTextArea, gbc);

        // Add components to the frame
        frame.add(panel);

        // Pack the frame to fit the preferred size of the components
        frame.pack();

        // Set the frame to be visible
        frame.setVisible(true);

        // Create and set up the menu bar
        fileMenu.add(exitMenuItem);
        menuBar.add(fileMenu);

        toolsMenu.add(processMenuItem);
        toolsMenu.add(clearMenuItem);
        toolsMenu.add(saveMenuItem);
        menuBar.add(toolsMenu);

        frame.setJMenuBar(menuBar);

        // Add action listeners
        exitMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        processMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                processReport();
            }
        });

        saveMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveReport();
            }
        });

        clearMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });
    }

    // Method to process the estate agent report
    private void processReport() {
        String location = (String) locationComboBox.getSelectedItem();
        String name = nameTextField.getText();
        String price = priceTextField.getText();
        String commission = commissionTextField.getText();

        Data data = new Data(location, name, price, commission);
        EstateAgent estateAgent = new EstateAgent();

        boolean isValid = estateAgent.ValidateData(data);

        if (isValid) {
            double calculatedCommission = estateAgent.CalculateCommission(price, commission);
            calculatedCommission = Math.round(calculatedCommission * 100.0) / 100.0;

            StringBuilder report = new StringBuilder();
            report.append("ESTATE AGENT REPORT\n");
            report.append("AGENT LOCATION: " + location + "\n");
            report.append("ESTATE AGENT NAME: " + name + "\n");
            report.append("PROPERTY PRICE: R " + price + "\n");
            report.append("COMMISSION PERCENTAGE: " + commission + "%\n");
            report.append("CALCULATED COMMISSION: R " + calculatedCommission + "\n");

            reportTextArea.setText(report.toString());
        } else {
            JOptionPane.showMessageDialog(frame, "Invalid input data. Please enter valid values.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }  
    
    // Method to save the estate agent report to a file
   private void saveReport() {
    String report = reportTextArea.getText();

    if (!report.isEmpty()) {
        try (FileWriter fw = new FileWriter("report.txt");
             BufferedWriter bw = new BufferedWriter(fw)) {

            // Format the report before saving
            
            /**
             * Java FileWriter (write to a file) 
             *Available at: https://www.youtube.com/watch?v=kjzmaJPoaNc
             */
            
            String formattedReport = "ESTATE AGENT REPORT\n****************************\n" + report;

            bw.write(formattedReport);

            JOptionPane.showMessageDialog(frame, "Report saved successfully. Please search 'report' manually on your computer.", "Success", JOptionPane.INFORMATION_MESSAGE);

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(frame, "An error occurred while saving the report.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(frame, "No report to save.", "Warning", JOptionPane.WARNING_MESSAGE);
    }
}

   // Method to clear all the input fields
    private void clearFields() {
        locationComboBox.setSelectedIndex(0);
        nameTextField.setText("");
        priceTextField.setText("");
        commissionTextField.setText("");
        reportTextArea.setText("");
    }

    // Main method to start the application
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new EstateAgentApp();
            }
        });
        /**
         * Java Swing Tutorial 2 : Creating First Project and invokeLater() method
         *Available at: https://www.youtube.com/watch?v=XttvrNIInoU
         */
    }
}
